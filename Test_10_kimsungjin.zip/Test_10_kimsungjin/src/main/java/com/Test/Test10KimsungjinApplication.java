package com.Test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test10KimsungjinApplication {

	public static void main(String[] args) {
		SpringApplication.run(Test10KimsungjinApplication.class, args);
	}

}
